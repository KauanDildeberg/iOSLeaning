/* Esse playground é um exemplo de class em meus estudos de POO*/


class Item {
    var unitPrice: Double = 0.0
    var discount: Double = 0.0
    var quantity: Int = 0
    var description: String?
    var id: String?
    
    init(id: String?, description: String?, quantity: Int, price: Double) {
        self.id = id
        self.description = description
        self.quantity = quantity
        unitPrice = price
        
    }
    
    init (){
        
    }
    
    func getAdjustedTotal() -> Double {
        let total: Double = unitPrice * Double(quantity)
        let totalDiscount: Double = total * discount
        let adjustedTotal: Double = total - totalDiscount
         
        return adjustedTotal
        
    }

    // Aplica uma porcentagem de desconto no preco
    
    func setDiscount(discount: Double) -> Double {
        self.discount = discount
        if discount >= 1.0 {
            self.discount = 1.0
        }
        return discount
    }
}

// main

var milk = Item(id: "dairy-011", description: "1Gallon Milk", quantity: 2, price: 2.50)
var yogurt = Item(id: "dairy-032", description: "Peach Yogurt", quantity: 4, price: 0.68)
var bread = Item(id: "bakery-023", description: "Sliced Bread", quantity: 1, price: 2.55)
var soap = Item(id: "household-021", description: "6 Pack Soap", quantity: 1, price: 4.51)

//Aplica descontos

milk.setDiscount(discount: 0.15)

//Obtem preços unitários

var milkPrice: Double = milk.getAdjustedTotal()
var yogurtPrice: Double = yogurt.getAdjustedTotal()
var breadPrice: Double = bread.getAdjustedTotal()
var soapPrice: Double = soap.getAdjustedTotal()

//imprimir recibo

print("Thank you for your purchase")
print("Please come again")
print("String\(milk.description!)     $\(milkPrice)")
print("String\(yogurt.description!)     $\(yogurtPrice)")
print("String\(bread.description!)     $\(breadPrice)")
print("String\(soap.description!)      $\(soapPrice)")



