//: A UIKit based Playground for presenting user interface
  
import UIKit

var array = [3,5,7,9,11]



print (array.map {$0+1})

let newArray = array.map {"\($0)"}
print(newArray)
